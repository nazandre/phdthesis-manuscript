#! /bin/bash

img="$1"
imgName=$(basename $img .png)

convert $img -background black -gravity center -extent 4032x3024 $imgName-scalled.png

#convert $img -resize 4032x3024< $imgName-scalled.jpg
